﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ePES.Entity;
using ePES.Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ePES.DAL;
using System.Text.RegularExpressions;

namespace ePES.BL
{
    public class PolicyValidations
    {
        PolicyOperations poloperations;

        public bool ValidatePolicy(Policy pol )  // policy class validation
        {
            bool isValidPolicy = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if(pol.policyNumber.ToString() == string.Empty )  // for policy number
                {
                    isValidPolicy = false;
                    sbError.Append("Please enter Policy Number");
                }
                else if(pol.policyNumber > 25 || pol.policyNumber < 11 || (pol.policyNumber > 15 && pol.policyNumber < 21))
                {
                    isValidPolicy = false;
                    sbError.Append("Please enter Policy Number between 11 to 15 ");
                }
                if (isValidPolicy == false)
                    throw new PolicyExceptions(sbError.ToString());
            }
            catch(PolicyExceptions ex)
            {
                throw ex;
            }
            return isValidPolicy;
        }

        public bool ValidateCustomer(Customer cust)  // customer class validation
        {
            bool isValidCustomer = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if(cust.customerName == string.Empty)   // for customer name
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Customer Name");
                }
                else if(!Regex.IsMatch(cust.customerName, "[A-Z][a-z, ]{1,}"))
                {
                    sbError.Append("Customer Name should start with Capital Alphabet, it should contain only alphabets\n");
                    isValidCustomer = false;
                }

                if(cust.customerID.ToString() == string.Empty)  // for customer ID
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Customer ID");
                }

                if(cust.customerDOB.ToString() == string.Empty)   // for Date of Birth
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Customer Date of Birth");
                }
                else if(!Regex.IsMatch(cust.customerDOB.ToString(), "mm/dd/yyyy"))
                {
                    sbError.Append("Customer Date of Birth should be in proper date format-- mm/dd/yyyy \n");
                    isValidCustomer = false;
                }
                if (isValidCustomer == false)
                    throw new PolicyExceptions(sbError.ToString());
            }
            catch(PolicyExceptions ex)
            {
                throw ex;
            }
            return isValidCustomer;
        }

        public DataTable GetPolicy_BLL(int custID, DateTime DOB, int PN, string Name)  // for search
        {
            DataTable dtCust;
            try
            {
                //call
                poloperations = new PolicyOperations();
                
                dtCust = poloperations.GetPolicy_DAL(custID, DOB, PN, Name);

            }
            catch (SqlException)
            {

                throw;
            }
            catch (PolicyExceptions)
            {
                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {


            }
            return dtCust;

        }

        
    }
}
