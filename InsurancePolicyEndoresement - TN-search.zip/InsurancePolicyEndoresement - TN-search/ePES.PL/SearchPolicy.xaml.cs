﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;



namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for SearchPolicy.xaml
    /// </summary>
    public partial class SearchPolicy : Window
    {
        public SearchPolicy()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtCustomerID.Clear();
            txtCustomerName.Clear();
            txtDOB.Clear();
            //dtpicker.ClearValue();
            txtPolicyNumber.Clear();
            //dgPolicy.ClearValue(;  // clear data grid 
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                PolicyValidations bllObj = new PolicyValidations();
                
                DataTable dtEmp = bllObj.GetPolicy_BLL(Convert.ToInt32(txtCustomerID.Text),Convert.ToDateTime(txtDOB.Text),Convert.ToInt32(txtPolicyNumber.Text),txtCustomerName.Text);
                dgPolicy.ItemsSource = dtEmp.DefaultView;

                
            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch(PolicyExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
