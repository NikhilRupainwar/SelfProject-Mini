﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ePES.Entity;
using ePES.Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ePES.DAL;
using System.Text.RegularExpressions;

namespace ePES.BL
{
    public class PolicyValidations
    {
        //PolicyOperations poloperations;

        //public static bool ValidatePolicy(int PN )  // policy class validation
        //{
        //    bool isValidPolicy = true;
        //    StringBuilder sbError = new StringBuilder();
        //    try
        //    {
        //        if(PN.ToString() == string.Empty )  // for policy number
        //        {
        //            isValidPolicy = false;
        //            sbError.Append("Please enter Policy Number NIKHIL");
        //        }
        //        else if(PN > 25 || PN < 11 || (PN > 15 && PN < 21))
        //        {
        //            isValidPolicy = false;
        //            sbError.Append("Please enter Policy Number between 11 to 15 or 21 to 25 NIKHIL");
        //        }
        //        if (isValidPolicy == false)
        //            throw new PolicyExceptions(sbError.ToString());
        //    }
        //    catch(PolicyExceptions ex)
        //    {
        //        throw ex;
        //    }
        //    return isValidPolicy;
        //}

        public static bool ValidateCustomer(int PN, int custID, DateTime custDob, string cname)  // customer class validation
        {
            bool isValidCustomer = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if(cname.ToString() == string.Empty)   // for customer name
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Customer Name \n");
                }
                else if(!Regex.IsMatch(cname, "[A-Z][a-z]+"))
                {
                    isValidCustomer = false;
                    sbError.Append("Customer Name should start with Capital Alphabet, it should contain only alphabets \n");
                    
                }

                if(custID.ToString() == string.Empty)  // for customer ID
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Customer ID \n");
                }

                if(custDob.ToString() == string.Empty)   // for Date of Birth
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Customer Date of Birth \n");
                }
                else if (custDob > DateTime.Now)
                {
                    isValidCustomer = false;
                    sbError.Append("Date of Birth should be less than present date \n");
                }
                //else if(!Regex. IsMatch(custDob.ToString(), "mm/dd/yyyy"))
                //{
                //    sbError.Append("Customer Date of Birth should be in proper date format-- mm/dd/yyyy \n");
                //    isValidCustomer = false;
                //}
                if (PN.ToString() == string.Empty)  // for policy number
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Policy Number \n");
                }
                else if (PN > 25 || PN < 11 || (PN > 15 && PN < 21))
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Policy Number between 11 to 15 or 21 to 25 \n");
                }
                if (isValidCustomer == false)
                    throw new PolicyExceptions(sbError.ToString());
            }
            catch(PolicyExceptions ex)
            {
                throw ex;
            }
            return isValidCustomer;
        }


       static DataTable dtCust;
        public static DataTable GetPolicy_BLL(int custID, DateTime DOB, int PN, string Name)  // for search
        {
 
            try
            {
                if (ValidateCustomer(PN, custID,DOB,Name))
                {

                 PolicyOperations poloperations = new PolicyOperations();
                    dtCust = PolicyOperations.GetPolicy_DAL(custID,DOB,PN,Name);
                }
                // poloperations = new PolicyOperations();

                // dtCust = PolicyOperations.GetPolicy_DAL(custID, DOB, PN, Name);
              
            }

            catch (SqlException ex)
            {

                throw ex;
            }
            catch (PolicyExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtCust;

        }

        
    }
}
