﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;

using System.Data;
using System.Data.SqlClient;

namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for ViewEndoDetails.xaml
    /// </summary>
    public partial class ViewEndoDetails : Window
    {
        public ViewEndoDetails()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            // int empid = Convert.ToInt32(mw.txt_ID_Search.Text);

            int id = Convert.ToInt32(txtcustomerID.Text);
            int pn = Convert.ToInt32(txtPolicyNumber.Text);
            PolicyValidations validationObj1 = new PolicyValidations();
            DataTable sEd = validationObj1.GetEndoPermanent_BL(id, pn);

            DataRow dr = sEd.Rows[0];

            if ((!dr.IsNull("customerID")) && (!dr.IsNull("policyNumber")))
            {              

                txtPolicyName.Text = dr["policyName"].ToString();

                txtProductLine.Text = dr["productLine"].ToString();

                txtInsuredName.Text = dr["customerName"].ToString();

                txtAddress.Text = dr["customerAddress"].ToString();

                txtTelephone.Text = dr["customerTelephone"].ToString();

                txtNomineeName.Text = dr["nomineeName"].ToString();

                txtNomineeRelation.Text = dr["nomineeRelation"].ToString();

                txtDOB.Text = dr["customerDOB"].ToString();

                txtGender.Text = dr["customerGender"].ToString();

                txtPremiumPaymentFrequency.Text = dr["premiumFrequency"].ToString();

                txtSmoking.Text = dr["customerSmoking"].ToString();

               


            }
            //else
            //    MessageBox.Show("No Records found with Emp Id : " + empid);


        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            UpdateDetails ud = new UpdateDetails();

            ud.txtID.Text = txtcustomerID.Text;
            ud.txtPolicyNumber.Text = txtPolicyNumber.Text;

            ud.Show();
        }
    }
}
