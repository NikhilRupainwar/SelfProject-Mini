﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;
using ePES.DAL;


namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for ViewEndorsementStatus.xaml
    /// </summary>
    public partial class ViewEndorsementStatus : Window
    {
        public ViewEndorsementStatus()
        {
            InitializeComponent();
        }

        

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                PolicyValidations bblObj = new PolicyValidations();
                LoginCredentials log = new LoginCredentials();
                log.userpassword = txtpswrdves.Text;
                DataTable dtEmp = bblObj.LoadEndorseCust_BLL(log);
                dgEndorsement.ItemsSource = dtEmp.DefaultView;
            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
    }
}
