﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;

namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for SearchPolicy.xaml
    /// </summary>
    public partial class SearchPolicy : Window
    {
        public SearchPolicy()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtCustomerID.Clear();
            txtCustomerName.Clear();
            //txtDOB.Clear();
            dtpicker.SelectedDate = DateTime.Now;
            txtPolicyNumber.Clear();
            //dgPolicy.ClearValue(;  // clear data grid 
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            int c_id;
            DateTime c_dob;
            int c_pn;
            string c_name;
            try
            {
                if (txtCustomerID.Text == string.Empty)
                {
                    c_id = 0;
                }
                else
                {
                    c_id = Convert.ToInt32(txtCustomerID.Text);
                }

                if (dtpicker.Text == string.Empty)
                {
                    c_dob = DateTime.MinValue;               //Convert.ToDateTime("01/01/1001");
                }
                else
                {
                    c_dob = Convert.ToDateTime(dtpicker.Text);
                }


                if (txtPolicyNumber.Text == string.Empty)
                {
                    c_pn = 0;
                }
                else
                {
                    c_pn = Convert.ToInt32(txtPolicyNumber.Text);
                }
                
                c_name = txtCustomerName.Text;

                DataTable dtEmp = PolicyValidations.GetPolicy_BLL(c_id, c_dob, c_pn, c_name);
                dgPolicy.ItemsSource = dtEmp.DefaultView;


            }
            catch (PolicyExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }


        private void btnViewDetails_Click(object sender, RoutedEventArgs e)
        {
            ViewEndoDetails ud = new ViewEndoDetails();
            ud.txtcustomerID.Text = txtCustomerID.Text;
            ud.txtPolicyNumber.Text = txtPolicyNumber.Text;

            ud.Show();
        }
    }
}
