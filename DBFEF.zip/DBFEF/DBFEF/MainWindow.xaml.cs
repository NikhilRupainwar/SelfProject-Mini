﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
/// <summary>
/// Name : Nikhil Rupainwar
/// Employee ID : 161770
/// Date : 17/10/2018
/// </summary>
namespace DBFEF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)   // display flat with owner details
        {
            Sep19CHNEntities contextObj = new DBFEF.Sep19CHNEntities();
            
           
                var query = from Owner own in contextObj.Owners
                            where own.DRA >= 20000  // filters
                            select own;
                List<Owner> clist = new List<DBFEF.Owner>(); // collection concept
                clist = query.ToList<Owner>();
                if (clist.Count <= 0) MessageBox.Show("No records found");

                dg_owner.ItemsSource = clist;
            
            
        }

        
    }
}
